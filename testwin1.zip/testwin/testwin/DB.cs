﻿using System;
using Microsoft.Data.Sqlite;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
namespace testwin
{
    public class DB
    {
        
       
       public MySqlConnection conn = new MySqlConnection("server=127.0.0.1;database=testwin;username=root;password=;");
        public DB()
        {
       
        }
        public bool openConnection()
        {

                   
                   if(conn.State == System.Data.ConnectionState.Closed)
                   {
                    conn.Open();
                    return true;
                   }
                   else
                   {
                    
                    return false;
                   }
                  
           // return true;
        }
        public bool closeConnection()
        {
          
            if (conn.State == System.Data.ConnectionState.Open)
            {
                conn.Close();
                return true;
            }
            else
            {
                return false;
            }
        }
        public MySqlConnection getConnection()
        {
            return conn;
        }

    }
}
