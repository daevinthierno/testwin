﻿using System;
using System.Windows.Forms;
using MailKit.Net.Smtp;
namespace testwin
{
    public class test: Form
    {
        public test()
        {
            MessageBox.Show("hello daivin");
        }
    }
}
