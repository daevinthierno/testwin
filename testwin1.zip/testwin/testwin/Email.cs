﻿using System;
using System.Net;
//using System.Net.Mail;
using MailKit;
using MailKit.Security;
using MailKit.Search;
using MailKit.Net.Proxy;
using MailKit.Net.Smtp;
using MimeKit;
namespace testwin
{
    public class Email
    {


        public Email()
        {
        }

        public bool SendMail(string ToEmail, int OTP)
        {
            bool test = false;
            try
            {

                MimeMessage message = new MimeMessage();
                BodyBuilder bodyBuilder = new BodyBuilder();

                message.From.Add(new MailboxAddress("daevin app", "daevintest@gmail.com"));
                message.To.Add(new MailboxAddress("", ToEmail));

                RegisterForm registerForm = new RegisterForm();
                message.Subject = "<h1>Hello " + registerForm.username() + "</h1>";

                bodyBuilder.HtmlBody = "your OTP code is " + OTP;
                message.Body = bodyBuilder.ToMessageBody();
                SmtpClient client = new SmtpClient();

                client.ServerCertificateValidationCallback = (s, c, h, e) => true;
                client.Connect("MAIL_SERVER", 465, SecureSocketOptions.SslOnConnect);
                client.Authenticate("daevintest", "daevintest123456");
                client.Send(message);
                client.Disconnect(true);
                test = true;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }



            return test;
        }
    }
}
