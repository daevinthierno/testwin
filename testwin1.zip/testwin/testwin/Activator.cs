﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testwin
{
    public class Activator : Form
    {
        private FlowLayoutPanel flowPanel;
        private Label labelActivator;
        private TextBox textBoxActivator;
        private Button button;
        public Activator()
        {
            ToolTip tip = new ToolTip();
            flowPanel = new FlowLayoutPanel();

            flowPanel.Dock = DockStyle.Fill;
            flowPanel.BorderStyle = BorderStyle.FixedSingle;
            flowPanel.BackColor = System.Drawing.Color.Orange;

            labelActivator = new Label();
            labelActivator.AutoSize = true;
            labelActivator.Cursor = System.Windows.Forms.Cursors.Hand;
            labelActivator.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            labelActivator.ForeColor = System.Drawing.Color.Black;
            labelActivator.Location = new System.Drawing.Point(146, 280);
            labelActivator.Name = "OTPlabel";
            labelActivator.Size = new System.Drawing.Size(163, 13);
            labelActivator.TabIndex = 7;
            labelActivator.Text = "Click here to activate your acount !!!";

            textBoxActivator = new TextBox();
            textBoxActivator.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            textBoxActivator.Location = new System.Drawing.Point(90, 145);
            textBoxActivator.Multiline = true;
            textBoxActivator.Name = "textBoxUsername";
            textBoxActivator.Size = new System.Drawing.Size(250, 50);
            textBoxActivator.TabIndex = 3;

            tip.SetToolTip(textBoxActivator, "enter activation code here");

            button = new Button();
            button.Text = "Submit";
            button.AutoSize = true;
            button.BackColor = System.Drawing.Color.Green;
            button.Size = new System.Drawing.Size(80, 20);
            button.Location = new System.Drawing.Point(300, 80);
            button.Click += new EventHandler(this.button_click);


            tip.SetToolTip(button, "click here to activate your account");


            flowPanel.Controls.Add(labelActivator);
            flowPanel.Controls.Add(textBoxActivator);
            flowPanel.Controls.Add(button);
            Controls.Add(flowPanel);

        }

        public void button_click(object sender, EventArgs e)
        {
            // MessageBox.Show("button ha been clicked");
            int MyActivationCode = Convert.ToInt32(textBoxActivator.Text);
            RegisterForm registerForm = new RegisterForm();
            int ActivationCode = registerForm.OTPvalue();

            if (MyActivationCode == ActivationCode)
            {
                DB db = new DB();
                db.openConnection();
                int userId = Convert.ToInt32(registerForm.UserID());
                String sql = "update users set activated = 0 where userId = "+userId;
                MySqlCommand command = new MySqlCommand(sql, db.getConnection());
                int result =  command.ExecuteNonQuery();
                if(result == 1)
                {
                    MessageBox.Show("Your account has been activated successfully");
                    LoginForm loginForm = new LoginForm();
                    loginForm.Show();
                }
            }
            else
            {
                MessageBox.Show("Incorrect Activation code. \n please check your emails and get valid activation code");
            }
        }
    }
}